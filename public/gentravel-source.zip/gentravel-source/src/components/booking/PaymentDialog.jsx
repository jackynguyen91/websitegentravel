import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Clock, Loader2, QrCode } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import CopyField from "@/components/booking/CopyField";
import { BANK, buildVietQRUrl, transferContent } from "@/lib/bank";
import { getBookingPaymentStatus, markTransferSubmitted } from "@/lib/server-fns";
import { formatDateVN, formatVND } from "@/lib/format";

export default function PaymentDialog({ booking, open, onOpenChange }) {
  const submitTransfer = useServerFn(markTransferSubmitted);
  const fetchStatus = useServerFn(getBookingPaymentStatus);
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState(booking?.payment_status || "Unpaid");

  const code = booking?.booking_code;
  const phone = booking?.customer_phone;

  useEffect(() => {
    setDone(false);
    setError("");
    setStatus(booking?.payment_status || "Unpaid");
  }, [code, booking?.payment_status]);

  // Tự động cập nhật trạng thái thanh toán khi chuyên viên xác nhận giao dịch.
  useEffect(() => {
    if (!open || !code || !phone || status === "Paid") return undefined;
    let active = true;
    const timer = setInterval(async () => {
      try {
        const res = await fetchStatus({ data: { booking_code: code, phone } });
        if (active && res?.payment_status) setStatus(res.payment_status);
      } catch {
        // bỏ qua lỗi mạng, lần kiểm tra sau sẽ thử lại
      }
    }, 8000);
    return () => {
      active = false;
      clearInterval(timer);
    };
  }, [open, code, phone, status, fetchStatus]);

  if (!booking) return null;

  const content = transferContent(booking);
  const amount = String(Math.round(Number(booking.total_price) || 0));
  const statusTone =
    status === "Paid"
      ? "border-emerald-200 bg-emerald-50 text-emerald-800"
      : status === "Pending Verification"
        ? "border-sky-200 bg-sky-50 text-sky-800"
        : "border-amber-200 bg-amber-50 text-amber-800";

  const handleTransferred = async () => {
    setError("");
    setSending(true);
    try {
      const res = await submitTransfer({
        data: { booking_code: booking.booking_code, phone: booking.customer_phone },
      });
      if (res?.error) setError(res.error);
      else {
        setStatus(res?.payment_status || "Pending Verification");
        setDone(true);
      }
    } catch {
      setError("Chưa ghi nhận được xác nhận. Vui lòng gọi 1900 6789 để được hỗ trợ ngay.");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] max-w-lg overflow-y-auto">
        <div className="text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-brand-50 text-brand">
            <QrCode className="h-6 w-6" />
          </span>
          <DialogTitle className="mt-3 font-heading text-xl font-extrabold text-ink">
            Xác nhận đặt tour & thanh toán
          </DialogTitle>
          <DialogDescription className="mt-1 text-[13px] text-slate-600">
            Mã đặt chỗ{" "}
            <span className="font-heading text-base font-extrabold tracking-wide text-brand">
              {booking.booking_code}
            </span>
          </DialogDescription>
        </div>

        <div
          className={`mt-4 flex items-start gap-2 rounded-xl border px-3 py-2.5 text-[12.5px] font-medium leading-relaxed ${statusTone}`}
        >
          {status === "Paid" ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          ) : status === "Pending Verification" ? (
            <Loader2 className="mt-0.5 h-4 w-4 shrink-0 animate-spin" />
          ) : (
            <Clock className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          <span>
            {status === "Paid"
              ? "Đã nhận thanh toán. Chỗ của bạn đã được giữ và vé điện tử sẽ được gửi qua Email/Zalo."
              : status === "Pending Verification"
                ? "Đã ghi nhận chuyển khoản của bạn, chuyên viên đang kiểm tra giao dịch."
                : "Đang chờ thanh toán. Cửa sổ này tự cập nhật ngay khi giao dịch được xác nhận."}
          </span>
        </div>

        <dl className="mt-4 space-y-2 rounded-xl bg-cloud p-4 text-[13px]">
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Tour</dt>
            <dd className="text-right font-medium text-ink">{booking.tour_title}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Ngày khởi hành</dt>
            <dd className="font-medium text-ink">{formatDateVN(booking.departure_date)}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-slate-500">Số khách</dt>
            <dd className="font-medium text-ink">
              {booking.adults_count} người lớn, {booking.children_count} trẻ em
            </dd>
          </div>
          <div className="flex justify-between gap-3 border-t border-slate-200 pt-2">
            <dt className="text-slate-500">Tổng tiền</dt>
            <dd className="font-heading text-base font-extrabold text-cta">
              {formatVND(booking.total_price)}
            </dd>
          </div>
        </dl>

        <div className="mt-4 rounded-2xl border border-slate-100 p-4 text-center">
          <img
            src={buildVietQRUrl(booking)}
            alt={`Mã VietQR thanh toán đơn ${booking.booking_code}`}
            className="mx-auto h-52 w-52 object-contain"
          />
          <p className="mt-2 text-[12px] text-slate-500">
            Mở ứng dụng ngân hàng và quét mã để chuyển đúng số tiền, đúng nội dung.
          </p>
        </div>

        <div className="mt-4 space-y-2">
          <div className="rounded-xl border border-slate-100 bg-white px-3 py-2.5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400">Ngân hàng</p>
            <p className="text-[13px] font-semibold text-ink">{BANK.name}</p>
          </div>
          <CopyField label="Số tài khoản" value={BANK.accountNumber} />
          <div className="rounded-xl border border-slate-100 bg-white px-3 py-2.5">
            <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-400">Chủ tài khoản</p>
            <p className="text-[13px] font-semibold text-ink">{BANK.accountName}</p>
          </div>
          <CopyField label="Số tiền (VND)" value={amount} display={formatVND(booking.total_price)} />
          <CopyField label="Nội dung chuyển khoản" value={content} emphasize />
          <p className="text-[11.5px] leading-relaxed text-slate-500">
            Vui lòng giữ nguyên nội dung chuyển khoản như trên để hệ thống xác minh nhanh nhất.
          </p>
        </div>

        {status === "Paid" ? (
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-[12.5px] font-medium leading-relaxed text-emerald-800">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Thanh toán đã được xác nhận. Vé điện tử và thông tin hướng dẫn viên sẽ được gửi qua Email/Zalo trong ít
              phút. Hẹn gặp bạn trong chuyến đi!
            </span>
          </div>
        ) : done ? (
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-[12.5px] font-medium leading-relaxed text-emerald-800">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              Cảm ơn bạn! Chuyên viên sẽ kiểm tra giao dịch trong vòng 15 phút. Bạn có thể giữ cửa sổ này mở, trạng
              thái sẽ tự cập nhật khi thanh toán được xác nhận.
            </span>
          </div>
        ) : (
          <>
            {error && (
              <p role="alert" className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-[12.5px] font-medium text-red-700">
                {error}
              </p>
            )}
            <button
              type="button"
              onClick={handleTransferred}
              disabled={sending}
              className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-cta text-sm font-semibold text-white transition hover:bg-cta-hover disabled:opacity-70"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {sending ? "Đang ghi nhận…" : "Tôi đã chuyển khoản"}
            </button>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}