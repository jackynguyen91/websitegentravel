import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { BarChart3, CalendarCheck, Compass, FileText, LogOut, MapPinned, ShieldAlert, Ticket } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";

const NAV = [
  { to: "/admin", label: "Tổng quan", icon: BarChart3, exact: true },
  { to: "/admin/bookings", label: "Đơn đặt tour", icon: CalendarCheck },
  { to: "/admin/tours", label: "Quản lý tour", icon: MapPinned },
  { to: "/admin/services", label: "Dịch vụ khác", icon: Ticket },
  { to: "/admin/blog", label: "Bài viết", icon: FileText },
];

export default function AdminLayout() {
  const { user, isLoadingAuth, logout } = useAuth();
  const { pathname } = useRouterState({ select: (state) => state.location });

  if (isLoadingAuth) {
    return <div className="grid min-h-screen place-items-center bg-cloud text-sm text-slate-500">Đang tải…</div>;
  }

  if (user?.role !== "admin") {
    return (
      <div className="grid min-h-screen place-items-center bg-cloud px-5">
        <div className="max-w-sm rounded-2xl border border-slate-100 bg-white p-8 text-center shadow-card">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-amber-50 text-amber-600">
            <ShieldAlert className="h-6 w-6" />
          </span>
          <h1 className="mt-4 font-heading text-lg font-extrabold text-ink">Khu vực dành cho quản trị viên</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600">
            Tài khoản {user?.email || "hiện tại"} không có quyền truy cập trang quản trị GenTravel.
          </p>
          <Link
            to="/"
            className="mt-5 inline-flex h-11 items-center rounded-xl bg-brand px-5 text-sm font-semibold text-white"
          >
            Về trang chủ
          </Link>
        </div>
      </div>
    );
  }

  const isActive = (item) => (item.exact ? pathname === item.to : pathname.startsWith(item.to));

  return (
    <div className="min-h-screen bg-cloud">
      <div className="mx-auto flex max-w-[1500px] flex-col lg:flex-row">
        <aside className="border-b border-slate-800/40 bg-ink text-slate-300 lg:sticky lg:top-0 lg:h-screen lg:w-64 lg:shrink-0 lg:border-b-0">
          <div className="flex items-center gap-2.5 px-5 py-4 lg:py-6">
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-brand text-white">
              <Compass className="h-5 w-5" strokeWidth={2.2} />
            </span>
            <div className="leading-none">
              <p className="font-heading text-[15px] font-extrabold text-white">
                Gen<span className="text-[#5EC8BC]">Travel</span>
              </p>
              <p className="mt-1 text-[10px] uppercase tracking-[0.16em] text-slate-500">Trang quản trị</p>
            </div>
          </div>

          <nav className="flex gap-1 overflow-x-auto px-3 pb-3 no-scrollbar lg:mt-2 lg:flex-col lg:overflow-visible">
            {NAV.map(({ to, label, icon: Icon, exact }) => (
              <Link
                key={to}
                to={to}
                className={`flex shrink-0 items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                  isActive({ to, exact })
                    ? "bg-white/10 text-white"
                    : "text-slate-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon className="h-4 w-4" />
                {label}
              </Link>
            ))}
          </nav>

          <div className="mt-auto hidden border-t border-white/10 p-4 lg:block">
            <p className="truncate text-[12.5px] font-semibold text-white">{user.full_name || user.email}</p>
            <p className="mt-0.5 truncate text-[11px] text-slate-500">{user.email}</p>
            <div className="mt-3 flex flex-col gap-1.5">
              <Link
                to="/"
                className="inline-flex h-9 items-center justify-center gap-2 rounded-lg border border-white/15 text-[12px] font-medium text-slate-300 transition hover:bg-white/10"
              >
                Về trang chủ
              </Link>
              <button
                type="button"
                onClick={() => logout("/")}
                className="inline-flex h-9 items-center justify-center gap-2 rounded-lg text-[12px] font-medium text-slate-400 transition hover:bg-white/10 hover:text-white"
              >
                <LogOut className="h-3.5 w-3.5" />
                Đăng xuất
              </button>
            </div>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 bg-white px-5 py-3 lg:hidden">
            <p className="text-[12.5px] font-medium text-slate-600">{user.full_name || user.email}</p>
            <button
              type="button"
              onClick={() => logout("/")}
              className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-500"
            >
              <LogOut className="h-3.5 w-3.5" /> Đăng xuất
            </button>
          </div>
          <div className="p-5 sm:p-8">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}