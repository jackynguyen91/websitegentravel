import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2, Search } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { formatDateVN, formatVND } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/bookings")({
  component: AdminBookings,
});

const STATUSES = ["Chờ xác nhận", "Đã xác nhận", "Đã thanh toán", "Đã hủy"];

const STATUS_STYLE = {
  "Chờ xác nhận": "bg-amber-50 text-amber-700 border-amber-200",
  "Đã xác nhận": "bg-sky-50 text-sky-700 border-sky-200",
  "Đã thanh toán": "bg-emerald-50 text-emerald-700 border-emerald-200",
  "Đã hủy": "bg-rose-50 text-rose-700 border-rose-200",
};

const PAYMENT_LABELS = {
  Unpaid: "Chưa thanh toán",
  "Pending Verification": "Chờ kiểm tra thanh toán",
  Paid: "Đã thanh toán",
};

const PAYMENT_STYLE = {
  Unpaid: "bg-amber-50 text-amber-700 border-amber-200",
  "Pending Verification": "bg-sky-50 text-sky-700 border-sky-200",
  Paid: "bg-emerald-50 text-emerald-700 border-emerald-200",
};

const asArray = (result) => (Array.isArray(result) ? result : (result?.items ?? []));

function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState("all");
  const [query, setQuery] = useState("");
  const [detail, setDetail] = useState(null);
  const [savingId, setSavingId] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      const rows = await base44.entities.Booking.list({ sort: "-created_date", limit: 300 });
      if (!alive) return;
      setBookings(asArray(rows));
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const text = query.trim().toLowerCase();
    return bookings.filter((booking) => {
      if (status !== "all" && booking.status !== status) return false;
      if (!text) return true;
      return [booking.booking_code, booking.customer_phone, booking.customer_name, booking.tour_title]
        .filter(Boolean)
        .some((field) => String(field).toLowerCase().includes(text));
    });
  }, [bookings, status, query]);

  const changeStatus = async (booking, nextStatus) => {
    setSavingId(booking.id);
    setBookings((prev) => prev.map((item) => (item.id === booking.id ? { ...item, status: nextStatus } : item)));
    try {
      await base44.entities.Booking.update(booking.id, { status: nextStatus });
    } finally {
      setSavingId(null);
    }
  };

  const confirmPayment = async (booking) => {
    setSavingId(booking.id);
    setBookings((prev) =>
      prev.map((item) =>
        item.id === booking.id ? { ...item, payment_status: "Paid", status: "Đã xác nhận" } : item,
      ),
    );
    try {
      await base44.entities.Booking.update(booking.id, {
        payment_status: "Paid",
        status: "Đã xác nhận",
      });
    } finally {
      setSavingId(null);
    }
  };

  return (
    <div>
      <h1 className="font-heading text-2xl font-extrabold tracking-tight text-ink">Đơn đặt tour</h1>
      <p className="mt-1 text-[13px] text-slate-500">
        Xác nhận đơn mới, cập nhật trạng thái thanh toán và tra cứu nhanh theo số điện thoại hoặc mã đặt chỗ.
      </p>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setStatus("all")}
          className={`h-9 rounded-lg border px-3 text-[12.5px] font-semibold transition ${
            status === "all" ? "border-ink bg-ink text-white" : "border-slate-200 bg-white text-slate-600"
          }`}
        >
          Tất cả ({bookings.length})
        </button>
        {STATUSES.map((item) => {
          const count = bookings.filter((booking) => booking.status === item).length;
          return (
            <button
              key={item}
              type="button"
              onClick={() => setStatus(item)}
              className={`h-9 rounded-lg border px-3 text-[12.5px] font-semibold transition ${
                status === item ? "border-brand bg-brand text-white" : "border-slate-200 bg-white text-slate-600"
              }`}
            >
              {item} ({count})
            </button>
          );
        })}
        <div className="relative ml-auto w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Tìm mã đơn, SĐT, tên khách…"
            className="h-10 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-[13px] text-ink outline-none focus:border-brand"
          />
        </div>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-card">
        {loading ? (
          <div className="grid h-40 place-items-center text-sm text-slate-400">Đang tải đơn đặt tour…</div>
        ) : filtered.length === 0 ? (
          <div className="grid h-40 place-items-center text-sm text-slate-500">Không có đơn nào khớp bộ lọc.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[1080px] text-left text-[13px]">
              <thead className="bg-cloud text-[11px] uppercase tracking-[0.08em] text-slate-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Mã đơn</th>
                  <th className="px-4 py-3 font-semibold">Khách hàng</th>
                  <th className="px-4 py-3 font-semibold">Tour</th>
                  <th className="px-4 py-3 font-semibold">Khởi hành</th>
                  <th className="px-4 py-3 text-center font-semibold">Khách</th>
                  <th className="px-4 py-3 text-right font-semibold">Tổng tiền</th>
                  <th className="px-4 py-3 font-semibold">Thanh toán</th>
                  <th className="px-4 py-3 font-semibold">Trạng thái</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((booking) => (
                  <tr key={booking.id} className="align-middle hover:bg-cloud/60">
                    <td className="px-4 py-3 font-heading font-bold text-brand">{booking.booking_code}</td>
                    <td className="px-4 py-3">
                      <p className="font-semibold text-ink">{booking.customer_name}</p>
                      <p className="text-[11.5px] text-slate-500">{booking.customer_phone}</p>
                    </td>
                    <td className="max-w-[220px] px-4 py-3">
                      <p className="truncate text-slate-700">{booking.tour_title}</p>
                      <p className="text-[11px] text-slate-400">{formatDateVN(booking.created_date, true)}</p>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{formatDateVN(booking.departure_date)}</td>
                    <td className="px-4 py-3 text-center text-slate-600">
                      {booking.adults_count} NL
                      {Number(booking.children_count) > 0 ? ` · ${booking.children_count} TE` : ""}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-ink">{formatVND(booking.total_price)}</td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col items-start gap-1">
                        <span
                          className={`rounded-lg border px-2 py-0.5 text-[11px] font-semibold ${PAYMENT_STYLE[booking.payment_status || "Unpaid"]}`}
                        >
                          {PAYMENT_LABELS[booking.payment_status || "Unpaid"]}
                        </span>
                        {booking.payment_status !== "Paid" && (
                          <button
                            type="button"
                            onClick={() => confirmPayment(booking)}
                            disabled={savingId === booking.id}
                            className="text-[11px] font-semibold text-brand hover:underline disabled:opacity-50"
                          >
                            Xác nhận đã nhận tiền
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <select
                          value={booking.status}
                          onChange={(event) => changeStatus(booking, event.target.value)}
                          className={`h-8 rounded-lg border px-2 text-[11.5px] font-semibold outline-none ${STATUS_STYLE[booking.status] || "border-slate-200 bg-white"}`}
                        >
                          {STATUSES.map((item) => (
                            <option key={item} value={item}>
                              {item}
                            </option>
                          ))}
                        </select>
                        {savingId === booking.id && <Loader2 className="h-3.5 w-3.5 animate-spin text-slate-400" />}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => setDetail(booking)}
                        className="text-[12px] font-semibold text-brand hover:underline"
                      >
                        Chi tiết
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={Boolean(detail)} onOpenChange={(open) => !open && setDetail(null)}>
        <DialogContent className="max-w-lg">
          <DialogTitle className="font-heading text-lg font-extrabold text-ink">
            Đơn {detail?.booking_code}
          </DialogTitle>
          <DialogDescription className="text-[12.5px] text-slate-500">
            Tạo lúc {formatDateVN(detail?.created_date, true)}
          </DialogDescription>
          <dl className="mt-4 space-y-2.5 text-[13px]">
            {[
              ["Tour", detail?.tour_title],
              ["Khách hàng", detail?.customer_name],
              ["Điện thoại", detail?.customer_phone],
              ["Email", detail?.customer_email],
              ["Ngày khởi hành", formatDateVN(detail?.departure_date)],
              ["Số khách", `${detail?.adults_count} người lớn · ${detail?.children_count} trẻ em`],
              ["Tổng tiền", formatVND(detail?.total_price)],
              ["Trạng thái", detail?.status],
              ["Thanh toán", PAYMENT_LABELS[detail?.payment_status || "Unpaid"]],
            ].map(([label, value]) => (
              <div key={label} className="flex justify-between gap-4 border-b border-slate-100 pb-2 last:border-0">
                <dt className="text-slate-500">{label}</dt>
                <dd className="max-w-[60%] text-right font-medium text-ink">{value || "—"}</dd>
              </div>
            ))}
          </dl>
          {detail?.special_requests && (
            <div className="mt-3 rounded-xl bg-cloud p-3">
              <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-slate-400">Yêu cầu đặc biệt</p>
              <p className="mt-1 text-[13px] leading-relaxed text-slate-700">{detail.special_requests}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}