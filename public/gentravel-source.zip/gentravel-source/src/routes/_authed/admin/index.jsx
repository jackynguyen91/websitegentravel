import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Banknote, CalendarClock, MapPinned, Ticket } from "lucide-react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { base44 } from "@/api/base44Client";
import StatCard from "@/components/admin/StatCard";
import { formatDateVN, formatVND } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/")({
  component: AdminOverview,
});

const asArray = (result) => (Array.isArray(result) ? result : (result?.items ?? []));

const STATUS_STYLE = {
  "Chờ xác nhận": "bg-amber-50 text-amber-700",
  "Đã xác nhận": "bg-sky-50 text-sky-700",
  "Đã thanh toán": "bg-emerald-50 text-emerald-700",
  "Đã hủy": "bg-rose-50 text-rose-700",
};

function AdminOverview() {
  const [bookings, setBookings] = useState([]);
  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const [bookingRows, tourRows] = await Promise.all([
        base44.entities.Booking.list({ sort: "-created_date", limit: 300 }),
        base44.entities.Tour.list({ sort: "-created_date", limit: 200 }),
      ]);
      if (!alive) return;
      setBookings(asArray(bookingRows));
      setTours(asArray(tourRows));
      setLoading(false);
    };
    load();
    // Đồng bộ tức thời khi đơn đặt tour được tạo mới hoặc xác nhận thanh toán.
    const unsubscribe = base44.entities.Booking.subscribe(() => load());
    return () => {
      alive = false;
      unsubscribe();
    };
  }, []);

  const isPaid = (booking) => (booking.payment_status || "Unpaid") === "Paid";
  const paid = bookings.filter(isPaid);
  const revenue = paid.reduce((sum, booking) => sum + (Number(booking.total_price) || 0), 0);
  const pending = bookings.filter((booking) => booking.status === "Chờ xác nhận").length;

  const now = new Date();
  const months = [];
  for (let i = 5; i >= 0; i -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({
      key: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`,
      label: `T${date.getMonth() + 1}`,
      bookings: 0,
      revenue: 0,
    });
  }
  bookings.forEach((booking) => {
    const slot = months.find((month) => month.key === String(booking.created_date || "").slice(0, 7));
    if (!slot) return;
    slot.bookings += 1;
    if (isPaid(booking)) slot.revenue += Number(booking.total_price) || 0;
  });

  const recent = bookings.slice(0, 5);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-extrabold tracking-tight text-ink">Tổng quan kinh doanh</h1>
          <p className="mt-1 text-[13px] text-slate-500">
            Theo dõi doanh thu, đơn đặt tour và hiệu suất bán hàng của GenTravel.
          </p>
        </div>
        <Link
          to="/admin/bookings"
          className="inline-flex h-10 items-center rounded-xl bg-brand px-4 text-[13px] font-semibold text-white"
        >
          Xử lý đơn đặt tour
        </Link>
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Doanh thu đã thanh toán" value={formatVND(revenue)} hint={`${paid.length} đơn đã thanh toán`} icon={Banknote} />
        <StatCard label="Đơn chờ xác nhận" value={pending} hint="Cần gọi khách trong 30 phút" icon={CalendarClock} tone="amber" />
        <StatCard label="Tour đang bán" value={tours.length} hint="Bao gồm tour trong nước và quốc tế" icon={MapPinned} tone="blue" />
        <StatCard label="Tổng đơn đặt tour" value={bookings.length} hint="Tất cả trạng thái" icon={Ticket} tone="violet" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-card">
          <div className="flex items-center justify-between">
            <h2 className="font-heading text-base font-bold text-ink">Đơn đặt tour theo tháng</h2>
            <span className="text-[11.5px] text-slate-400">6 tháng gần nhất</span>
          </div>
          <div className="mt-4 h-[260px]">
            {loading ? (
              <div className="grid h-full place-items-center text-sm text-slate-400">Đang tải dữ liệu…</div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={months} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: "#64748B" }} />
                  <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: "#64748B" }} />
                  <Tooltip
                    formatter={(value, name) => [name === "bookings" ? `${value} đơn` : formatVND(value), name === "bookings" ? "Đơn đặt tour" : "Doanh thu"]}
                    contentStyle={{ borderRadius: 12, border: "1px solid #E2E8F0", fontSize: 12 }}
                  />
                  <Bar dataKey="bookings" fill="#0F766E" radius={[6, 6, 0, 0]} maxBarSize={44} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-card">
          <h2 className="font-heading text-base font-bold text-ink">Đơn mới nhất</h2>
          <div className="mt-3 space-y-3">
            {loading ? (
              <p className="text-sm text-slate-400">Đang tải…</p>
            ) : recent.length === 0 ? (
              <p className="text-sm text-slate-500">Chưa có đơn đặt tour nào.</p>
            ) : (
              recent.map((booking) => (
                <div key={booking.id} className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                  <div className="min-w-0">
                    <p className="truncate text-[13px] font-semibold text-ink">{booking.customer_name}</p>
                    <p className="truncate text-[11.5px] text-slate-500">
                      {booking.booking_code} · {formatDateVN(booking.created_date)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[12.5px] font-semibold text-ink">{formatVND(booking.total_price)}</p>
                    <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${STATUS_STYLE[booking.status] || "bg-slate-100 text-slate-600"}`}>
                      {booking.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}