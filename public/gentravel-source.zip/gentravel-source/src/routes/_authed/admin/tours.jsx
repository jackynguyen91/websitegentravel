import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Eye, Pencil, Plus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import TourFormDialog from "@/components/admin/TourFormDialog";
import { Image } from "@/components/ui/image";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { durationLabel, finalPrice, formatVND } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/tours")({
  component: AdminTours,
});

const asArray = (result) => (Array.isArray(result) ? result : (result?.items ?? []));

function AdminTours() {
  const [tours, setTours] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);

  const load = async () => {
    const rows = await base44.entities.Tour.list({ sort: "-created_date", limit: 200 });
    setTours(asArray(rows));
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const openEdit = (tour) => {
    setEditing(tour);
    setDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!deleting) return;
    await base44.entities.Tour.delete(deleting.id);
    setDeleting(null);
    await load();
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-extrabold tracking-tight text-ink">Quản lý tour</h1>
          <p className="mt-1 text-[13px] text-slate-500">Tạo mới, chỉnh sửa lịch trình và giá bán cho từng hành trình.</p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="inline-flex h-10 items-center gap-2 rounded-xl bg-brand px-4 text-[13px] font-semibold text-white"
        >
          <Plus className="h-4 w-4" /> Thêm tour
        </button>
      </div>

      <div className="mt-5 overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-card">
        {loading ? (
          <div className="grid h-40 place-items-center text-sm text-slate-400">Đang tải danh sách tour…</div>
        ) : tours.length === 0 ? (
          <div className="grid h-40 place-items-center text-sm text-slate-500">Chưa có tour nào. Hãy tạo tour đầu tiên.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-[13px]">
              <thead className="bg-cloud text-[11px] uppercase tracking-[0.08em] text-slate-500">
                <tr>
                  <th className="px-4 py-3 font-semibold">Tour</th>
                  <th className="px-4 py-3 font-semibold">Danh mục</th>
                  <th className="px-4 py-3 font-semibold">Thời lượng</th>
                  <th className="px-4 py-3 text-right font-semibold">Giá bán</th>
                  <th className="px-4 py-3 text-center font-semibold">Nổi bật</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tours.map((tour) => (
                  <tr key={tour.id} className="hover:bg-cloud/60">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-16 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                          {tour.cover_image ? (
                            <Image src={tour.cover_image} alt={tour.title} className="h-full w-full" fittingType="fill" />
                          ) : null}
                        </div>
                        <div className="min-w-0">
                          <p className="truncate font-semibold text-ink">{tour.title}</p>
                          <p className="text-[11.5px] text-slate-500">
                            {tour.destination} · khởi hành từ {tour.departure_point}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{tour.category}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {durationLabel(tour.duration_days, tour.duration_nights)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <p className="font-semibold text-ink">{formatVND(finalPrice(tour))}</p>
                      {Number(tour.discount_percent) > 0 && (
                        <p className="text-[11px] text-slate-400">giảm {tour.discount_percent}%</p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`inline-block rounded-full px-2 py-0.5 text-[10.5px] font-semibold ${
                          tour.is_featured ? "bg-brand-50 text-brand" : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {tour.is_featured ? "Nổi bật" : "Thường"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Link
                          to="/tours/$slug"
                          params={{ slug: tour.slug }}
                          aria-label="Xem tour"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-brand"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </Link>
                        <button
                          type="button"
                          onClick={() => openEdit(tour)}
                          aria-label="Sửa tour"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-brand"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleting(tour)}
                          aria-label="Xóa tour"
                          className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 hover:border-red-200 hover:text-red-600"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <TourFormDialog open={dialogOpen} onOpenChange={setDialogOpen} tour={editing} onSaved={load} />

      <AlertDialog open={Boolean(deleting)} onOpenChange={(open) => !open && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogTitle className="font-heading text-lg font-extrabold text-ink">Xóa tour này?</AlertDialogTitle>
          <AlertDialogDescription className="text-[13px] text-slate-600">
            Tour “{deleting?.title}” sẽ bị xóa khỏi website. Các đơn đặt tour đã ghi nhận vẫn được giữ lại.
          </AlertDialogDescription>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-xl border border-slate-200 px-4 text-[13px] font-semibold text-slate-600">
              Giữ lại
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="h-10 rounded-xl bg-red-600 px-4 text-[13px] font-semibold text-white hover:bg-red-700"
            >
              Xóa tour
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}